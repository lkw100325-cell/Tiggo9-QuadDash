package com.tiggo9.quaddash;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.graphics.Typeface;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {
    private LinearLayout root;
    private TextView status;
    private boolean recording = false;
    private int selected = -1;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().getDecorView().setSystemUiVisibility(
            View.SYSTEM_UI_FLAG_FULLSCREEN | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION |
            View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
        buildUi();
    }

    private int dp(float v) { return (int)(v * getResources().getDisplayMetrics().density + 0.5f); }

    private TextView label(String text, int size, int color) {
        TextView t = new TextView(this);
        t.setText(text); t.setTextSize(size); t.setTextColor(color);
        t.setGravity(Gravity.CENTER); return t;
    }

    private void buildUi() {
        root = new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(12), dp(8), dp(12), dp(8)); root.setBackgroundColor(Color.rgb(13,17,23));
        setContentView(root);

        LinearLayout header = new LinearLayout(this);
        header.setGravity(Gravity.CENTER_VERTICAL);
        TextView title = label("瑞虎9 · 四路行车记录仪", 22, Color.WHITE);
        title.setTypeface(null, Typeface.BOLD);
        header.addView(title, new LinearLayout.LayoutParams(0, dp(44), 1));
        status = label("预览版｜尚未连接视频源", 13, Color.rgb(255,190,70));
        header.addView(status, new LinearLayout.LayoutParams(-2, dp(44)));
        root.addView(header);

        LinearLayout grid = new LinearLayout(this); grid.setOrientation(LinearLayout.VERTICAL);
        LinearLayout row1 = new LinearLayout(this), row2 = new LinearLayout(this);
        addPane(row1, "前摄像头", 0); addPane(row1, "后摄像头", 1);
        addPane(row2, "左摄像头", 2); addPane(row2, "右摄像头", 3);
        LinearLayout.LayoutParams rowLp = new LinearLayout.LayoutParams(-1, 0, 1);
        rowLp.bottomMargin = dp(6);
        grid.addView(row1, rowLp);
        grid.addView(row2, new LinearLayout.LayoutParams(-1, 0, 1));
        root.addView(grid, new LinearLayout.LayoutParams(-1, 0, 1));

        LinearLayout controls = new LinearLayout(this); controls.setGravity(Gravity.CENTER_VERTICAL);
        Button rec = button("开始录像"); rec.setOnClickListener(v -> {
            recording = !recording;
            rec.setText(recording ? "停止录像" : "开始录像");
            status.setText(recording ? "演示状态：录像按钮已开启" : "预览版｜尚未连接视频源");
            status.setTextColor(recording ? Color.RED : Color.rgb(255,190,70));
            Toast.makeText(this, recording ? "这是界面演示：尚未写入视频文件" : "已关闭演示状态", Toast.LENGTH_SHORT).show();
        });
        Button playback = button("录像回放"); playback.setOnClickListener(v ->
            Toast.makeText(this, "回放功能需接入真实视频录像模块后启用", Toast.LENGTH_LONG).show());
        Button settings = button("设置"); settings.setOnClickListener(v ->
            Toast.makeText(this, "当前为界面验证版，摄像头/存储配置尚未接入", Toast.LENGTH_LONG).show());
        controls.addView(rec); controls.addView(playback); controls.addView(settings);
        root.addView(controls);
        TextView note = label("注意：当前版本仅验证界面，不会读取原车360摄像头，也不会实际录制视频。", 12, Color.LTGRAY);
        root.addView(note, new LinearLayout.LayoutParams(-1, dp(26)));
    }

    private void addPane(LinearLayout row, String name, int idx) {
        LinearLayout pane = new LinearLayout(this); pane.setOrientation(LinearLayout.VERTICAL);
        pane.setGravity(Gravity.CENTER); pane.setBackgroundColor(Color.rgb(31,39,49));
        pane.setPadding(dp(6), dp(6), dp(6), dp(6));
        TextView nameView = label(name, 18, Color.WHITE); nameView.setTypeface(null, Typeface.BOLD);
        pane.addView(nameView);
        TextView placeholder = label("等待视频信号", 14, Color.rgb(170,180,190));
        pane.addView(placeholder);
        pane.setOnClickListener(v -> {
            selected = idx;
            Toast.makeText(this, name + "：尚未接入摄像头视频源", Toast.LENGTH_SHORT).show();
        });
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, -1, 1);
        lp.setMargins(dp(3), dp(3), dp(3), dp(3));
        row.addView(pane, lp);
    }

    private Button button(String text) {
        Button b = new Button(this); b.setText(text); b.setAllCaps(false);
        return b;
    }
}
